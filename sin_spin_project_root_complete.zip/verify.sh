#!/bin/sh

make format && make lint && make test
